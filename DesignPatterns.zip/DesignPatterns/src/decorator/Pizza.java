package decorator;

public interface Pizza 
{

	
	public String makePizza();
	public int getPrice();
	
}

abstract class PizzaDecorator implements Pizza
{
	private Pizza p;
	public PizzaDecorator(Pizza p)
	{
		this.p=p;
		
	}
	
	public String makePizza()
	{
		return p.makePizza();
	}

	public int getPrice()
	{
		return p.getPrice();
	}
	

}

class VegPizza implements Pizza
{

	@Override
	public String makePizza() {
		// TODO Auto-generated method stub
		return "Veg Pizza";
	}

	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return 200;
	}
	

}

class ChickenPizza  extends PizzaDecorator
{

	public ChickenPizza(Pizza p) {
super(p);
	}
	@Override
	public String makePizza() {
		// TODO Auto-generated method stub
		return  super.makePizza()+ "With Chciken Strips";
	}

	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return super.getPrice() +90;
	}
	

}


class FishPizza  extends PizzaDecorator
{

	public FishPizza(Pizza p) {
super(p);
	}
	@Override
	public String makePizza() {
		// TODO Auto-generated method stub
		return  super.makePizza()+ "With shrimps";
	}

	@Override
	public int getPrice() {
		// TODO Auto-generated method stub
		return super.getPrice() +190;
	}
	

}


