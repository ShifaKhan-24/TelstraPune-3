package decorator;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		VegPizza veg=new VegPizza();
		System.out.println(veg.makePizza());
		System.out.println("Price:"+ veg.getPrice());
		
		Pizza chicken=new ChickenPizza(new VegPizza());
		chicken.makePizza();
		System.out.println(chicken.makePizza());
		System.out.println("Price:"+ chicken.getPrice());
		
		
		Pizza fish=new FishPizza(new VegPizza());
		fish.makePizza();
		System.out.println(fish.makePizza());
		System.out.println("Price:"+ fish.getPrice());
	}

}
