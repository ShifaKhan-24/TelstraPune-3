package factory;


	public class CNG extends Fuel
	{
	 @Override
	 void getRate()
	 {
	  rate=86.00;
	 }
	}


