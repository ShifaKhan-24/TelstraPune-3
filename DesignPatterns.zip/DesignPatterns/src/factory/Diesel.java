package factory;

public class Diesel extends Fuel {

	@Override
	 void getRate()
	 {
	  rate=76.75;
	 }

}
