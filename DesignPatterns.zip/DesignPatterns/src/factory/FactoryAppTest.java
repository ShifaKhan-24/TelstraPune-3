package factory;

public class FactoryAppTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		FuelFactory factory=new FuelFactory();
		Fuel fuel=factory.getFuel("petrol");
		
		
		fuel.getRate();
		System.out.println(fuel.calcPrice(700));
		
		
		

}
}