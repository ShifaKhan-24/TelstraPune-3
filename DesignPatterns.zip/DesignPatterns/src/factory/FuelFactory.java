package factory;

public class FuelFactory {

	
	public Fuel getFuel(String fuelType)
	{
		
		if(fuelType.equals("petrol"))
			return new Petrol();
		
		else if(fuelType.equals("diesel"))
			return new Diesel();
		

		
		else if(fuelType.equals("cng"))
			return new CNG();

		else 
			return null;
		
	
	}
}
