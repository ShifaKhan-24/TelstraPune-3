package factory;

public class Petrol extends Fuel {

	@Override
	 void getRate()
	 {
	  rate=96.35;
	 }

}
