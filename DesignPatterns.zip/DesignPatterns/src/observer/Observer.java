package observer;

import java.util.ArrayList;
import java.util.List;

public abstract class Observer {
	protected Mobile s; // this will be the subject concept here
    public abstract void update();
}


 class Mobile
{
    private List<Observer> observers = new ArrayList<Observer>();
    private String state;
    public String getState()           {return state;}
    public void attach(Observer o)  {observers.add(o);}
    public void setState(String state)
    {
        this.state = state;
        notifyAllObservers();
    }
    
    private void notifyAllObservers()
    {
        for (Observer o : observers)
            o.update();
    }
}
 
 
  class UserOneObserver extends Observer
 {
    public UserOneObserver(Mobile s)
    {
        this.s = s;
        this.s.attach(this);
    }
    @Override
    public void update()
    {
    	System.out.println(s.getState());
    }
}
  
  
  
  class UserTwoObserver extends Observer
  {
     public UserTwoObserver(Mobile s)
     {
         this.s = s;
         this.s.attach(this);
     }
     @Override
     public void update()
     {
     	System.out.println(s.getState());
     }
 }
  
  
  