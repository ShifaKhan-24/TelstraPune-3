package observer;

public class ObserverTestClient {


		public static void main(String[] args)
	    {
	        Mobile m = new Mobile();
	        
	        new UserOneObserver(m);
	        new UserTwoObserver(m);
	      
	        System.out.println("First state change!");
	        m.setState("Available");
	        System.out.println("Second state change!");
	        m.setState("Unavailble");
	    }    
	}


