package strategy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

interface Maths
{
    public float calc(float num1, float num2);
}
class Addition implements Maths
{
    @Override
    public float calc(float num1, float num2)
    {return num1 + num2;}
}

class Subtraction implements Maths
{
    @Override
    public float calc(float num1, float num2)
    {return num1 - num2;}
}



class Context 
{
    private Maths m;
    public Context(Maths m) {this.m = m;}
    
    public float calc (float num1, float num2)
    {return m.calc(num1, num2);}
}
public class StrategyPatternDemo {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        float num1, num2;
        System.out.print("Enter the first number: ");
        num1 = Float.parseFloat(br.readLine());
        System.out.print("Enter the second number: ");
        num2 = Float.parseFloat(br.readLine());
		System.out.println("Addition: " + new Context(new Addition()).calc(num1, num2));
        System.out.println("Subtraction: " + new Context(new Subtraction()).calc(num1, num2));
	}

}
