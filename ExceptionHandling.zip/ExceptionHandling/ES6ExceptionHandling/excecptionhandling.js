class ExceptionDemo
{

    //  constructor(value,value1)
    //  {
    //     console.log(value,value1)
    //      let x=value/value1 ;
    // console.log(x)
    //  }

   divide(a, b) {

console.log(typeof(Error))
    try {
            if (b === 0) {
                throw  new Error("Division by zero is not allowed.");
                // or simple write Error(message)
                //throw  Error("Division by zero is not allowed.");
             }
             let result = a / b;
            console.log(`Result: ${result}`);
         } catch (e) {
             //console.error(`Error: ${e}`);
             console.error(`${e}`)
        // console.log(e);
            } finally {
         // return 0;
            console.log("Division operation completed.");
            return 0;
         }
    }
}


//let excp=new ExceptionDemo()
let excp=new ExceptionDemo(10,0)
excp.divide(10,0)