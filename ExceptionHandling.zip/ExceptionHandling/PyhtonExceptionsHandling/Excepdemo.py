result = 0


class Expdemo:
    
    def calculate(self, num1, num2):
        
        try:
            result = num1 / num2
        except ZeroDivisionError:
            print("Exception handled")
        else:
            print("Result is:", result)
        finally:
            print("Result is finally", result)


expobj = Expdemo()
expobj.calculate(10, 1)
    

# class Expdemo1:
#     def calculate(num1, num2):
        
#         try:
#             result = num1 / num2
#         except ZeroDivisionError as ex:

#             print("Exception handled", ex)
#         else:
#             print("Result is:", result)
   
    
