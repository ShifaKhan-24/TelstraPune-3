class Expdemo:
    
    def calculate(self, num1, num2):
        result = None
        try:
            result = num1 / num2
        except ZeroDivisionError:

            print("Exception handled")
            
        finally:
            print("Inside Finnaly")
            print("Result",  result)


expobj = Expdemo()
expobj.calculate(10, 3)
