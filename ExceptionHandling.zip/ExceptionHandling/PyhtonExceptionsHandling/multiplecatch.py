class Expdemo:
    def calculate(self, num1, num2):
        
        try:
            result = int(num1) / int(num2)
        except ZeroDivisionError as ze:

            print("Exception handled", ze)
        except ValueError as v:

            print("Value Error handled", v)
        else:
            print("Result is:", result)
   
    
expobj = Expdemo()
expobj.calculate(10, 2)


class MultipleExcpdemo:
    def calculate(self, num1, num2):
        
        try:
            result = int(num1) / int(num2)
        except (ZeroDivisionError, ValueError) as e:
            print("Exception handled", e)
        
        except Exception as e1:
            print("Default exception handeld", e1)
            
        else:
            print("Result is:", result)
            
   
expobj1 = MultipleExcpdemo()

expobj1.calculate(10, 3)


