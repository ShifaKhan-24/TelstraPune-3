function greetings()
{

    console.log("Welcome to Functional Programming")
}

// or
let display=() => console.log("Functional Programming")

display();


function sum(x,y)
{
return x+y;

}
console.log(sum(10,20))

// the same can be writen has

const add =(x,y) =>
    { 
        return x+ y
    }
console.log(add(10,20))

let square=x=> x*x; // single parameter ie square(x)

let multiply=(x,y)=> x*y; // multiple parameter ie square(x,y)

