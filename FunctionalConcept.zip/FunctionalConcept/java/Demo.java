

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

// Passing the behaviour to another functions or asasigning the behaviour to a varible
		
		Greetings g=(x)-> System.out.println(" Hello:"+ x);
		
		
		g.greetings("Shifa");
		
		
		 
	}

}
