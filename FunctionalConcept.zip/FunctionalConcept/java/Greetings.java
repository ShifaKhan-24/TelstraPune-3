

@FunctionalInterface
public interface Greetings 
{

	
	void greetings(String message);
	
	
	
	default void banner()
	{
		
	}
	
	
}
