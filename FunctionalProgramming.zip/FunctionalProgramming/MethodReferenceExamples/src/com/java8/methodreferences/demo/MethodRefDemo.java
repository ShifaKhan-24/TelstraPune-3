

package com.java8.methodreferences.demo;

import java.util.function.Consumer;


public class MethodRefDemo {

	public static void main(String[] args) 
	{
	
		
		Thread t=new Thread(()->printInfo());
		
		t.start();
		
		
Thread t1=new Thread(MethodRefDemo:: printInfo);
		
		t1.start();


		printInfo1(10,System.out::println);
	}
	
	
	public static void printInfo()
	{
		
	System.out.println("Method Referernce");	
	}

	
	public static int printInfo1(int a,Consumer<Integer> input)
	{
	return  a+100;	
		
	}
}
