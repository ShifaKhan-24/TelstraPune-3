
package com.java8.methodreferences.demo;
import java.util.Optional;




interface  Calculator
{
	
	double getmesqrt(float x);
	
}











interface HandleButtonEvents
{
	
	void onClick();
	default String getAppData(String s)
	{
		return s;
	}
}

class App
{
	App()
	{
		System.out.println("hello from App");
	}

	
	App(String s)
	{
		System.out.println("Overloaded:"+s);
	}

	static void ButtonClick()
	{
		System.out.println("Button click perfromed");
	}
	
	 void ButtonPressed()
	{
		System.out.println("Button Pressed");
	}
	
}

public class UnderstandingMethodReferences {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//System.out.println(Math.sqrt(100));
		
		
		Calculator cimpl=(value)->
		{
			
			return 10.88;
		};
		
		
		
Calculator c=(m)->Math.sqrt(m);





System.out.println(c.getmesqrt(100));

Calculator c1=Math::sqrt;
System.out.println(c1.getmesqrt(9));





/*

Calculator c1=Math::sqrt;
System.out.println(c1.get(9));

// Classic way with lambdas

HandleButtonEvents event=()->
{
	App.ButtonClick();
	
};
event.onClick();



// with static method refernce

HandleButtonEvents events=App::ButtonClick;




events.onClick();

App obj=new App();

HandleButtonEvents events1=App::ButtonPressed;

HandleButtonEvents events1=new App()::ButtonPressed;
events1.onClick();

HandleButtonEvents events2=App:: new;

HandleButtonEvents events3=App:: new;
System.out.println(events3.getAppData("abc"));



String str=null;
Optional<String> op1=Optional.of(str);

Optional<String> op=Optional.ofNullable(str);
op.ifPresent(System.out::println);


//String s=Optional.ofNullable(str).get();
//System.out.println(s);
*/

}
	
	
	
}