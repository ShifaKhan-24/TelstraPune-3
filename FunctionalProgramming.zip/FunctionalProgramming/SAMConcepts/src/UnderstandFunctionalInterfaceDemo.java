
// This interface can qualify has functional interface because it has only 1 abstract method

interface SAM
{
	
	void disp();
}

//This interface can qualify has functional interface because it has only 1  abstract  method
// and also declared with the annotation "FunctionalInterface"
@FunctionalInterface
interface SAM1
{
	
	void disp();
}
//This interface can qualify has functional interface because it has only 1 abstractmethod
// It can have any number of default methods
//it can also have any static methods

interface SAM2
{
	
	void disp();
	default void print()
	{
		
	}
	
	static void show()
	{
		
	}
}



public class UnderstandFunctionalInterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
