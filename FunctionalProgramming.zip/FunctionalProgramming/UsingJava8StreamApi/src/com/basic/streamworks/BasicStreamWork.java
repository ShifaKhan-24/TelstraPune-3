package com.basic.streamworks;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class BasicStreamWork {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Stream<Integer> stream1 = Stream.of(1,2,3,4,5);

		
		
        stream1.forEach(p -> System.out.println(p));

        

        System.out.println("****************************************************");

        Stream<Integer> stream2 = Stream.of( new Integer[]{1,2,3,4,5} );

        stream2.forEach(p -> System.out.println(p));

        

        System.out.println("****************************************************");

        List<String> list = new ArrayList<String>();

        list.add("Java");
        list.add("Unix");
        list.add("Oracle");
        Stream<String> stream3 = list.stream();
        stream3.forEach(p -> System.out.println(p));

        

        System.out.println("****************************************************");

        IntStream stream4 = "Java8_Stream".chars();

        stream4.forEach(p -> System.out.println(p));
	}

}
