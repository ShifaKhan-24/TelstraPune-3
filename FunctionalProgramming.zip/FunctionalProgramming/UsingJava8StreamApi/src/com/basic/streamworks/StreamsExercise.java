package com.basic.streamworks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

class Products
{
int pid;
String proname;
String description;
double price;
String brand;
public Products(int pid, String proname, String description, double price,
		String brand) {
	super();
	this.pid = pid;
	this.proname = proname;
	this.description = description;
	this.price = price;
	this.brand = brand;
}
public int getPid() {
	return pid;
}
public String getProname() {
	return proname;
}
public String getDescription() {
	return description;
}
public double getPrice() {
	return price;
}
public String getBrand() {
	return brand;
}
public void setPid(int pid) {
	this.pid = pid;
}
public void setProname(String proname) {
	this.proname = proname;
}
public void setDescription(String description) {
	this.description = description;
}
public void setPrice(double price) {
	this.price = price;
}
public void setBrand(String brand) {
	this.brand = brand;
}
@Override
public String toString() {
	return "Products [pid=" + pid + ", proname=" + proname + ", description="
			+ description + ", price=" + price + ", brand=" + brand + "]";
}

@Override
public boolean equals(Object obj){
   Products prod = (Products) obj;
    boolean status = false;
    if(this.proname.equalsIgnoreCase(prod.proname)
            
    		
    		
    		
    		&& this.brand.equalsIgnoreCase(prod.brand) )
            
    
    {
        status = true;
    }
    return status;
}


@Override
public int hashCode() {
    return brand.hashCode();
}
}


public class StreamsExercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		List<Products> product=Arrays.asList(
				new Products(101, "Shampoo", "Long and Strong Hair", 100, "Pantine"), 
				new Products(502, "Body wash", "Smooth and clear skin", 200, "Lux"), 
				new Products(303, "Baby Soap", "for babies", 150, "Dettol"), 
				new Products(210, "Hand Wash", "Kills 99.9% germs", 50, "Dettol")
				
				
				);
		
		// Task 1: Print  All products 
		
		product.stream().forEach(System.out::println);
		
		
		// Task 2: Print  All products with unique brandnames;
		
		List <String> temp=new ArrayList<>();
		
		product.stream().distinct().
		
		forEach(p->temp.add(p.getBrand()));
		
		
System.out.println(temp);



System.out.println("***********************************");

List<String> list = new ArrayList<>();
product.stream()
.filter(n -> n.getBrand().equals("Dettol"))
.forEach(p -> list.add(p.getProname()));


System.out.println(list);

// Task 3 : Price with some condition

product.stream().filter(e->e.price <150).forEach(System.out::println);
	
}
}
