package com.basic.streamworks;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class UsingStreamImportantMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

//1. Using map, we can transform the items in the collection to the objects by applying the function passed as argument.

        //Using collect, we can convert result of the intermediate operations performed on the streams to collections

        List<Integer> numList = Arrays.asList(1, 2, 3, 4);

        List<Integer> squareList = numList.stream().map(i -> i * i).collect(Collectors.toList());

        System.out.println(squareList);// Prints [1, 4, 9, 16]

 

        System.out.println("******************************************************************");

        //2. Using filter, we can filter the elements of this stream that match the given predicate.

        List<String> names = Arrays.asList("Java", "Oracle", "Unix", "Python", "Machine Learning", "Spring Boot");

        List<String> filteredNames = names.stream().filter(s -> s.length() > 3).collect(Collectors.toList());

        System.out.println(filteredNames);
               

        System.out.println("******************************************************************");

        //3. Using sorted, we can sort the stream

        List <String> sortedNames = names.stream().sorted().collect(Collectors.toList());

        System.out.println(sortedNames);
               

        System.out.println("******************************************************************");

        //4. Using collect we can convert result of the intermediate operations performed on the streams to collections

        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);

        //Converting to list

        List<Integer> evenNumbersList = numbers.stream().filter(i -> i % 2 == 0).collect(Collectors.toList());

        System.out.println(evenNumbersList);//Prints [2, 4, 6, 8]

               

        //Converting to set

        Set<Integer> oddNumbersSet = numbers.stream().filter(i -> i % 2 == 1).collect(Collectors.toSet());

        System.out.println(oddNumbersSet);//Prints [1, 3, 5, 7, 9]

               

        System.out.println("******************************************************************");

        //5. Using toArray we can convert result of the intermediate operations performed on the streams to array

        Integer[] evenNumbersArr = numbers.stream().filter(i -> i % 2 == 0).toArray(Integer[]::new);

        for(int i : evenNumbersArr) {System.out.print(i + " ");}//Prints 2 4 6 8

               

        System.out.println("\n******************************************************************");

        //6. Using forEach, we can iterate through every element of the stream

        List<String> memberNames = Arrays.asList("Java", "Oracle", "Unix", "Python", "Machine Learning", "Spring Boot");

        memberNames.stream().sorted().forEach(name -> System.out.print(name + " "));
        

               

        System.out.println("\n******************************************************************");

        //7. Using reduce, we can perform a reduction on the elements of the stream with the given BiFunction.

        //The result is an Optional holding the reduced value.

        Optional<String> commaSeparatedNames = memberNames.stream().reduce((s1, s2) -> s1 + "," + s2);

        System.out.println(commaSeparatedNames);
        //Prints Optional[Java,Oracle,Unix,Python,Machine Learning,Spring Boot]               
	}

}
