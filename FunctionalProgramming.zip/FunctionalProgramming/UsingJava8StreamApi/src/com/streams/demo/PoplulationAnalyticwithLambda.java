package com.streams.demo;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PoplulationAnalyticwithLambda {

	public static void main(String[] args) {

		
List<Country> cdata=Arrays.asList(
				
				new Country("India",1370000000),
				new Country("USA",1270000000),
				new Country("China",1470000000),
				new Country("Pakistan",1170000000)
				);
Collections.sort(cdata,(Country c1,Country c2)->c1.getCountryname().compareTo(c2.getCountryname()));
printAll(cdata);


System.out.println("************************************By Population************************");
Collections.sort(cdata,(c1,c2)->Long.compare(c1.getPopulation(),c2.getPopulation()));

printAll(cdata);


	
	}




	public static void printAll(List<Country> cdata)
	{
		for(Country c:cdata)
		{
			System.out.println(c);
		}
		
	}
	
	
}


