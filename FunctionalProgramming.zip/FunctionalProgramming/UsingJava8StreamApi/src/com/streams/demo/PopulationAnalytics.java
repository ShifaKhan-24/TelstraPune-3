package com.streams.demo;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PopulationAnalytics {

	
	public static void main(String[] args) 
	{
	
	       List<Country> cdata=Arrays.asList(
			new Country("India",1370000000),
			new Country("USA",1270000000),
			new Country("China",1470000000),
			new Country("Pakistan",1170000000)
			);
	
	       Collections.sort(cdata, new Comparator<Country>()
			{
		@Override
				public int compare(Country o1, Country o2) {
					// TODO Auto-generated method stub
					return o1.getCountryname().compareTo(o2.getCountryname());
				}
				});// end of sorting by country name

	
	Collections.sort(cdata, new Comparator<Country>()
			{

				@Override
				public int compare(Country o1, Country o2) {
					// TODO Auto-generated method stub
					
				if (o1.getPopulation() < o2.getPopulation())
				{	
					return -1;
				}
				else if(o1.getPopulation() > o2.getPopulation())
				{
					return 1;
				}
				
				else 
					return 0;
				
				}
		
		
		
			});
	
	
	
	
	
	printAll(cdata);
	
	
	
	
	
	}



public static void printAll(List<Country> cdata)
{
	for(Country c:cdata)
	{
		System.out.println(c);
	}
	
}

}
