package com.streams.demo;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class PopulationAnalyticsv1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			
		List<Country> cdata=Arrays.asList(
				
				new Country("India",1370000000),
				new Country("USA",1270000000),
				new Country("China",1470000000),
				new Country("Pakistan",1170000000)
				);
		
		
		
		
		cdata.stream().sorted(Comparator.comparingLong(Country::getPopulation)).collect(Collectors.toList()).
		forEach(cname->System.out.println(cname.getPopulation()  +" ||"+cname.getCountryname()));
		
		// Lets print the same using Streams
		
		cdata.stream().forEach(cname->System.out.println(cname.getCountryname()));
		
		//cdata.stream().sorted().forEach(cname->System.out.println(cname.getCountryname()));
		
		
		
		cdata.stream().sorted(Comparator.comparingLong(Country::getPopulation)).collect(Collectors.toList()).forEach(cname->System.out.println(cname.getPopulation()  +" ||"+cname.getCountryname()));
		
		
		
		
		System.out.println("****************************");
		// By Country Name
		cdata.stream().sorted(Comparator.comparing(Country::getCountryname)).collect(Collectors.toList()).forEach(cname->System.out.println(cname.getCountryname() + "  ||     "+cname.getPopulation()));
		
		
		cdata.stream().forEach(cname->System.out.println(cname.getCountryname()));
		
	
	
	}

}
