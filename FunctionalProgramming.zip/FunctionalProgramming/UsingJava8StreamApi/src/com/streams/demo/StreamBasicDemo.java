package com.streams.demo;

import java.util.stream.Stream;

class Employee
{
	
	
	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + "]";
	}
	

	public Employee(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	String name;
	int id;
	
	
	public boolean equals(Object obj){
       Employee emp = (Employee) obj;
        boolean status = false;
        if(this.name.equalsIgnoreCase(emp.name))
                
        
        {
            status = true;
        }
        return status;
    }
	
	
}
public class StreamBasicDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Employee emp[]={
			new Employee("xx",10),new Employee("yyy",1000)	
				
		};
		
		
		


























/*for(Employee x:emp)
		{
			System.out.println(x);
		}*/
		//Stream<Employee> empstream=Stream.of(emp);


		Stream<Employee> empstream=Stream.of(new Employee[]{new Employee("abc",20),new Employee("xxx",9)});
				
		
		
		
		empstream.forEach(System.out::print);
				
				//empstream.filter(e->e.id <10).forEach(System.out::println);
			System.out.println(empstream.allMatch(e->e.name.startsWith("a")));
			
		//empstream.allMatch(e->e.name.);
				
	}
	
	
	

}
