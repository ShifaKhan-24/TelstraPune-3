package com.withjava7;

public class Country 
{
private String countryname;

private long population;


public Country(String countryname, long population)
{
	super();
	this.countryname = countryname;
	this.population = population;
}

public String getCountryname() {
	return countryname;
}
public void setCountryname(String countryname) {
	this.countryname = countryname;
}
public long getPopulation() {
	return population;
}


public void setPopulation(long population) 
{
	this.population = population;
}


@Override
public String toString() {
	return "Country [countryname=" + countryname + ", population=" + population
			+ "]";
}



}
