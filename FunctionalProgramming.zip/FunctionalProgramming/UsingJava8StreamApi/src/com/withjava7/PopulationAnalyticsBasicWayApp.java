package com.withjava7;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class PopulationAnalyticsBasicWayApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	       List<Country> cdata=Arrays.asList(
			new Country("India",1370000000),
			new Country("USA",1270000000),
			new Country("China",1470000000),
			new Country("Pakistan",1170000000)
			);
	
	       Collections.sort(cdata,new SortPopulationByCountryName());
	       
	       System.out.println("****************Result****************");
	System.out.println(cdata);

	
	
	
	
	}
	
	
	

}
