package com.withjava7;

import java.util.Comparator;

public class SortPopulationByCountryName implements Comparator<Country>
{

	@Override
	public int compare(Country o1, Country o2) {
		// TODO Auto-generated method stub
		return o1.getCountryname().compareTo(o2.getCountryname());
	}

	
	
	
	
}
