class Book {
  constructor(bookName, price) {
    this.bookName = bookName;
    this.price = price;
    this.next = null; // For linked list
  }
}

class Author {
  constructor(authorName, address) {
    this.authorName = authorName;
    this.address = address;
    this.bookList = null; // Head of the linked list
  }

  addBook(book) {
    if (!this.bookList) {
      this.bookList = book;
    } else {
      let current = this.bookList;
      while (current.next) {
        current = current.next;
      }
      current.next = book;
    }
  }

  getBooks() {
    let books = [];
    let current = this.bookList;
    while (current) {
      books.push(current);
      current = current.next;
    }
    return books;
  }

  printBooks() {
    let current = this.bookList;
    console.log(`Books by ${this.authorName}:`);
    while (current) {
      console.log(`- ${current.bookName} (Price: $${current.price})`);
      current = current.next;
    }
  }
}

// Pure function to get books with price greater than 200
function getBooksWithPriceGreaterThan200(author) {
  const books = author.getBooks();
  return books.filter(book => book.price > 200);
}

// Example usage:
const book1 = new Book("The Secret", 150);
const book2 = new Book("Good Girls Guide", 250);
const book3 = new Book("Harry Potter", 300);
const book4 = new Book("Goosebumps", 300);

const author1 = new Author("Danny", "Address1");
author1.addBook(book1);
author1.addBook(book2);
author1.addBook(book3);
author1.addBook(book4);

// Output all books by the author
author1.printBooks(); // Prints all books in a readable format

// Get books with price > 200
const expensiveBooks = getBooksWithPriceGreaterThan200(author1);

// Print books with price > 200
console.log(`\nBooks by ${author1.authorName} with price greater than $200:`);
expensiveBooks.forEach(book => {
  console.log(`- ${book.bookName} (Price: $${book.price})`);
});
