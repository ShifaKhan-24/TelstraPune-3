# Knowing Data Types in Python
print(type(100))
print(type("Jagadish"))
print(type('A'))
print(type(10.5))
print(type(100.666))
print(type(False))

mydata = [1, "abb", 10.6]

print(type(mydata))
mydata = [2, 'c', 10.7]
print(mydata)

mytuple = (1, "ssss", 'c', 20)
myset = {2, 5, 2, 7}

print(mytuple)
print(myset)

#mytuple.append("xxx")

# or lets say we want to update  with index it will not be possible has they are immutable
mytuple[0] = 10

