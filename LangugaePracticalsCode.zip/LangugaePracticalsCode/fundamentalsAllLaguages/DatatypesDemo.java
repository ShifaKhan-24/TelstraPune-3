class Demo
{
    public static void main(String a[])
    {

      // Note: String is not a datatype in Java
    // Primitive Data Types
    int numval=10;
    float decval=10.5f;
    char alpha='J';
    double dval=10.777;
    boolean status=true;
    short s=10;
    byte b=100;

long l=100;
System.out.println(numval);
System.out.println(decval);
System.out.println(dval);
System.out.println(alpha);
System.out.println(s);
System.out.println(b);
System.out.println(l);



    }
}