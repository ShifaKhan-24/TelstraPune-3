public class Javaarray {
    
    public static void main(String[] args) {
        int arr[]={1,3,4,5};
       
        int arr1[]=new int[4];

        
        int multiarr[][]={
{1,3},
{4,5}

        };

int multiarr1[][]=new int[2][2];


}
}
