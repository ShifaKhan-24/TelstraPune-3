message = "Welcome All to Python"
print(type(message))
print(message)