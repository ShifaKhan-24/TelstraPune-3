


// Creating array using new keyword 

let numArray = new Array(3);


numArray[0] = 100;

numArray[1] = 150;

numArray[2] = 200;

const languages = new Array("Java", "Python", "JS-ES6");




// Creating array using array literals  
let numArray1 = [1.5, 2, 23];
 x = numArray1[1]; 
console.log(x)


let strArray = ['Java', 'Python','ES6'];

let c = strArray[0]; 

console.log(c)
console.log("Size:"+strArray.length)


//Array Destructuring
let deStructureArray = [1.5, 2, 0x12, 5, 3.9];

let a1;

let b1;

let c1;

[a1,b1,c1] = deStructureArray;
console.log(a1)

