console.log(typeof(10))
console.log(typeof('A'))
console.log(typeof("Abc"))
console.log(typeof(true))
console.log(typeof(10.5))
var x=new String("MyString")

console.log(typeof(x))
let myarry=new Array(3);
console.log(typeof(myarry))

