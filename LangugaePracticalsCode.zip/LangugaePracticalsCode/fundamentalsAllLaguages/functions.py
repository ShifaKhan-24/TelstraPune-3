def greetings():
    print("welcome")
    

greetings()    

# defining a function


def sum(a, b):
    print("Sum of two values=", (a+b))
# calling function


sum(20, 30)

#return type


def sum(a, b):
    c = a + b
    return c


x = sum(1, 2)
print("Sum of two numbers is: ", x)


# or muliple values
def m1(a, b):
    c = a+b
    d = a-b
    return c, d
# calling function


x, y = m1(10, 5)
print("sum of a and b: ", x)
print("subtraction of a and b: ", y)

# one function call another function


def m1():
    print("first function information")
 
 
def m2():
  
    print("second function information")
  
    m1()
    m2()
    
    # Assign function to varaible
    
        
def add():
       
    print("We assigned function to variable")


#  Assign function to variable
sum = add
#  calling function
sum()

# pass function as a parameter to another function


def display(x):
    print("This is display function") 


def message():
    print("This is message function")

# calling function


display(message())