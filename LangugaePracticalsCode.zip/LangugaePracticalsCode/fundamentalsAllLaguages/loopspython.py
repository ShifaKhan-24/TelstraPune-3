# while loop
# for loop
number = 1

while number <= 3:
    print(number)
    number = number + 1
    # Print numbers until the user enters 0
value = int(input('Enter a number: '))

# iterate until the user enters 0
while value != 0:
    print(f'You entered {value}.')
    value = int(input('Enter a number: '))

print('The end.')


data = 1
while (data < 10):
    print(data)
    data = data + 1
    
    
print("Over")


