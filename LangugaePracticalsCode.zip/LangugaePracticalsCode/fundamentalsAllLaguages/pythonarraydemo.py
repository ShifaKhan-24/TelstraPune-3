
import array as arr

a = arr.array('i', [2, 6, 9, 11])

print(a[0])

# slicing the array here : is a slice operator
numarray = [2, 5, 62, 5, 42, 52, 48, 5]
num_array = arr.array('i', numarray)

print(num_array[2:5]) # 3rd to 5th
print(num_array[:-5]) # beginning to 4th
print(num_array[5:])  # 6th to end
print(num_array[:])   # beginning to end

numbers = arr.array('i', [1, 2, 3, 5, 7, 10])

# changing first element
numbers[0] = 0    
print(numbers)     # Output: array('i', [0, 2, 3, 5, 7, 10])

# changing 3rd to 5th element
numbers[2:5] = arr.array('i', [4, 6, 8])   

number = arr.array('i', [1, 2, 3, 3, 4])
# Removing array elements

# del number[2]  # removing third element
# print(number)  # Output: array('i', [1, 2, 3, 4])

# del number  # deleting entire array
# print(number)  # Error: array is not defined
# print(numbers)     # Output: array('i', [0, 2, 4, 6, 8, 10])

numx = [10, 20, 30, 40]
print(type(numx))

dem = 10.5
print(type(dem))

x = int(dem)
print(type(x))







