# if statement
# if-else statement
# if elif else
num = 1
print("num==1 condition gives: ", (num == 1))
if num == 1:
    print("if block statements executed")
    
    num1 = 1
print("num==1 condition gives: ", (num1 == 1))
if num1 == 2:
    print("if block statements executed")
else:
    print("else block statements executed")

# elif demo
x = 7
if x == 0:
    print("You entered:", x)

elif x == 1:
    print("You entered:", x)

elif x == 2:
    print("You entered:", x)

elif x == 3:
    print("You entered:", x)

elif x == 4:
    print("You entered:", x)
else:
    print("Beyond the range than specified")