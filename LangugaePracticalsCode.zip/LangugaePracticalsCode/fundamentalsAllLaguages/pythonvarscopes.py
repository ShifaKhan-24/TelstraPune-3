def showData():
    global greetings
    greetings = "Global Varibale"
    mesg = "Hello Local"
    print(mesg)
    print(greetings)
    
    mesg = "Again local"
    
    
showData()
# print(mesg) # error
print(greetings)