class Product{
    
  addDetails()
  {
  
    let pid=101;
     let pname="Laptop";
  
  return {pid,pname};
    }  
  showDetails()
  {
    //   console.log("Product Id:"+this.pid);
      console.log("Product Name:"+this.pname);// undefined 

      console.log("Product Name:"+this.addDetails());
  }
  
  }
    let person = new Product();
    console.log(person.addDetails())
    console.log(person.showDetails())