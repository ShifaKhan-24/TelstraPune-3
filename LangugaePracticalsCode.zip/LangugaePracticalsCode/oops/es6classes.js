/* What are the members of JavaScript ES6 class?
 Fields/Variables 
Constructors 
 Methods 
 Inner class and interface 
********************
 Syntax
class ClassName{
constructor
field;    
 method;    
 }  
*/

class Product
{
  static message="Welcome"  
  pid;
  pname;
addDetails()
{
   this. pid=101;
   this.pname="Laptop";
}  
showDetails()
{
    console.log("Greetings:"+Product.message)
    console.log("Product Id:"+this.pid);
    console.log("Product Name:"+this.pname);
    
}
static banner(){
    console.log("Produt Details"+this.pid)
  }
}
Product.banner();  

let product = new Product();
//product.banner()  
  console.log(product.addDetails())
  console.log(product.showDetails())