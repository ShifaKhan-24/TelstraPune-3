class Product
{
// more then one constructor not possible
// constructor()
// {
//     console.log("inside default")
// }
    constructor(pid,pname)
    {
     
        console.log("inside constructor"+pid)
pid=100;
pname="Laptop";
console.log(pname)
    }

    showDetails()
    {
        return new  Product(this.pid ,this.pname);
        // console.log(this.pid)
        // console.log(this.pname)

    }
}

let product=new Product(200,"ABC")
product.showDetails()