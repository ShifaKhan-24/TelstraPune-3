class Product
{
productList = new Array(3);
    constructor(pid,pname)
    {
     
        console.log("Product Id:"+pid)
        console.log("Product Name"+pname)
       
    }

    showProducts(productList)
    {
        console.log("Products displayed:"+productList)
    }
    
}


class Order extends Product
{
    productList = new Array(3);
    constructor(pid1,pname1,oid,qty,price)
    {
super(pid1,pname1);

console.log("Order Id:"+oid);
console.log("Quantity:"+qty);
console.log("Price:"+price);

    }
     printOrder(productList)
    {
super.showProducts(productList)
    }

}
let order=new Order(101,"Laptop",1,100,90000)
const plist = ["Keyboard", "Mouse", "Joystick"];
order.printOrder(plist)
