from abc import ABC, abstractmethod
# Abstract Class


class Employee(ABC):
    @abstractmethod
    def work(self):
        print("All Employees do work")
        pass


class Manager(Employee):
    def work(self):
        
        print("Doing Manegerial Work")
        
      
class Clerk(Employee):
    def work(self):
        
        print("Doing Clerical Work")
        
           
clerk = Clerk()
clerk.work()
clerk = Manager()
clerk.work()

# or
emp: Employee
emp = Clerk()
emp.work()

emp = Manager()
emp.work()
