class Product:
    
    banner = "Products List"  # Static varible
    
    
pro = Product()
pro.pid = 10
pro.pname = "Laptop" 
    
print(pro.pid)
print(Product.banner)
