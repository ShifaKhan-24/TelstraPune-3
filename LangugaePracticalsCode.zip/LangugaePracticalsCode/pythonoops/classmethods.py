class Product:
    def showProduct(self, prid, prname):
        print("Display all products", prid, prname)

    @staticmethod
    def addProducts(prid, prname):
        print("Adding products", prid, prname)
    
    
pro = Product()
    

pro.showProduct(10, "Laptop")
Product.addProducts(100, "Gaming")