class Product:
    def __init__(self):
        print("Construtors")
        
        
pro = Product()


class Order:
    def __init__(self, oid, qty, price):
        self.oid = oid
        print("Construtors", self.oid)
        
        
pro = Product()
ord = Order(10, 20, 8000)

         