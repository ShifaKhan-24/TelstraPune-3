class Product:
    def showProducts(self):
        print("Parent class method")
        
        
class Order(Product):
    def showOrders(self):
        print("Child class  method")
        
        
orderobj = Order()
orderobj.showOrders()
orderobj.showProducts
