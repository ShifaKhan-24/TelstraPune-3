# no separate keyword to create interface use abstract method only
from abc import ABC, abstractmethod
# Abstract Class


class ConnectDB(ABC):
    @abstractmethod
    def connect(self, url, username, password):
        print("Connection Management to differnt DB")
        pass


class Oracle(ConnectDB):
    def connect(self, url, username, password):
        
        print("Oracle Connection Details:", url, username, password)
        
      
class MySql(ConnectDB):
    def connect(self, url, username, password):
        
        print("Oracle Connection Details:", url, username, password)
        
   
dbconnect: ConnectDB
dbconnect = MySql()
dbconnect.connect("oracleurl@1521", "scott", "tiger")
dbconnect = Oracle()
dbconnect.connect("mmysqlurl@3306", "root", "admin")

