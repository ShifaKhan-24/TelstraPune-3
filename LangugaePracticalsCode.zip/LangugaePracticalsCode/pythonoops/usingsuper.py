class Product:
    def __init__(self):
        
        print("Parent class constructor")
        
        
class Order(Product):
    def __init__(self):
        # Product.__init__(self)
        print("Child class constructor")
        super().__init__()
        
           
orderobj = Order()

