public class BankService {

	
	public long deposit(long account,String accountNo)
	{
		
		return 0;
	}
	
	public long withDraw(long amount,String accountNo)
	{
		
		return 0;
	}
	
	
	public void printPassBook()
	{
		
		// code to update Passbook details
	}
	
	
	public void getLoanInterestInfo(String loanType)
	{
		
		if(loanType.equals("Home"))
		{
			
			// do some job
		}
		
		if(loanType.equals("Car"))
		{
			
			// do some job
		}
		
		if(loanType.equals("personalLoan"))
		{
			
			// do some job
		}
	}
	public void sendOtp(String medium)
	{
		if(medium.equals("phone"))
		{
			// do some job
			
		}
		
		
	}
	
	// here the class has mutiple reason to change ,in future they may introduce
	// new loan type and also sendotop via email 

	
	// so what is the solution
	// we can move the code of loan to Loan Service and sendOtp to Notifcation Service
	// printPassbook to PrinterService so that achieves SRP CONCEPT
	
	
	
}
