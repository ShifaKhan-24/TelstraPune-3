
public class LoanService 
{


	public void getLoanInterestInfo(String loanType)
	{
		
		if(loanType.equals("Home"))
		{
			
			// do some job
		}
		
		if(loanType.equals("Car"))
		{
			
			// do some job
		}
		
		if(loanType.equals("personalLoan"))
		{
			
			// do some job
		}
	}

}
