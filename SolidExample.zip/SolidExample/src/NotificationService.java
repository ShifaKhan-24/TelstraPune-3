
public class NotificationService {

	public void sendOtp(String medium)
	{
		if(medium.equals("phone"))
		{
			// do some job
			
		}
		
		
	}

	// now you can add other medium here
}
