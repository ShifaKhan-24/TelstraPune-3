
public class PrinterService {
	public void printPassBook(String accountNo)
	{
		
		// code to update Passbook details
	}

}
