package dip;

public class CreditCard {

	public void doTransaction(long amount)
	{
		System.out.println("Credit Card Transaction");
	}
	
}
