package dip;

public class DebitCard {

	public void doTransaction(long amount)
	{
		System.out.println("Debit Card Transaction");
	}
}
