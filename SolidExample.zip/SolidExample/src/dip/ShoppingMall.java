package dip;
// lets assume this class procees the paymemt with credit card
// tughtly couple concept whic is not recomended,
//we need to loosely couple to ensure that it accepts any card

import dipsolution.BankCard;

public class ShoppingMall {

	
	
	//private CreditCard card;
	private BankCard bcard;
	
//	public ShoppingMall(CreditCard card)
//	{
//		this.card=card;
//		
//	}
	
	public ShoppingMall(BankCard card)
	{
		this.bcard=bcard;
		
	}
	public void doPurchase(long amount)
	{
		card.doTransaction(amount);
		//bcard.doTransaction(amount);
		
	}
	
	
	public static void main(String ap[])
	{
		
		DebitCard db=new DebitCard();
		CreditCard cd=new CreditCard();
		
		ShoppingMall sp=new ShoppingMall(db);// here its error has we cant use debit card
		
		sp.doPurchase(10000);
		
	}
}
