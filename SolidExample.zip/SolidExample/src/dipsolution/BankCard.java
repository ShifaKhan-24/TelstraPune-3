package dipsolution;

public interface BankCard {
	public void doTransaction(long amount);
	

}

