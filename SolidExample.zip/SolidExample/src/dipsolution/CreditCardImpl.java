package dipsolution;

public class CreditCardImpl implements BankCard {

	@Override
	public void doTransaction(long amount) {
		// TODO Auto-generated method stub
System.out.println("Credit card Transaction");
	}

}
