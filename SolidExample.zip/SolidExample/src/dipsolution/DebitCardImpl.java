package dipsolution;

public class DebitCardImpl implements BankCard {

	@Override
	public void doTransaction(long amount) {
		// TODO Auto-generated method stub
System.out.println("Debit Transaction");
	}

}
