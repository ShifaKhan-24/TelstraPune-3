package isp;

import ispsolution.CashBackManager;

public class Gpay implements UPIPayments ,CashBackManager {
// here lets assume all these features are applicable to gPay 
	@Override
	public void payMoney() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getScratchCard() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getCashBackasOffer() {
		// TODO Auto-generated method stub

	}

}
