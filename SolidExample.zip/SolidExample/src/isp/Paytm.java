package isp;

public class Paytm implements UPIPayments {
// Now lets imagine  getCashBackasOffer()  is not supported, we are here force
	// client overide this method ,so this is not
	
	
	@Override
	public void payMoney() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getScratchCard() {
		// TODO Auto-generated method stub

	}

	/*
	 * @Override public void getCashBackasOffer() { // TODO Auto-generated method
	 * stub
	 * 
	 * }
	 */

}
