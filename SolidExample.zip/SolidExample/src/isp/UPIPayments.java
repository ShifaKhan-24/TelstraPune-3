package isp;

public interface UPIPayments {
	
	void payMoney();
	void getScratchCard();
	//void getCashBackasOffer();
	

}
