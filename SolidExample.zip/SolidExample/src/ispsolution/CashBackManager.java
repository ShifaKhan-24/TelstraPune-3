package ispsolution;

public interface CashBackManager 
{
	void getCashBackasOffer();
	
	
}
