package lsp;

public class FacebookClient extends SocialMedia
{

	@Override
	public void chatWithFriend() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void publishPost() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sharePhotos() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void shareVideos() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void makeGroupVideos() {
		// TODO Auto-generated method stub
		
	}

}
