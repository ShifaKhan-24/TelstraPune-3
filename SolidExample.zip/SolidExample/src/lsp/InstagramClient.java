package lsp;

public class InstagramClient extends SocialMedia {

	@Override
	public void chatWithFriend() {
		// TODO Auto-generated method stub

	}

	@Override
	public void publishPost() {
		// TODO Auto-generated method stub

	}

	@Override
	public void sharePhotos() {
		// TODO Auto-generated method stub

	}

	@Override
	public void shareVideos() {
		// TODO Auto-generated method stub

	}

	@Override
	public void makeGroupVideos() {
		// TODO Auto-generated method stub
// here this also a not applicable for instagram has it does not suuport
		// hence this is also not liskov
		// Instagram chile is not asubstuitie of parent Social Media
		
	}

}
