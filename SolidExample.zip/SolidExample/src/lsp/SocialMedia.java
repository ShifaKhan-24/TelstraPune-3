package lsp;

public abstract class SocialMedia {
// support for whatsapp,facebook,instagram etc
	public abstract void chatWithFriend();

	
	// support for whatsapp,facebook,instagram etc
		public abstract void publishPost();
		
		// support for whatsapp,facebook,instagram etc
		public abstract void sharePhotos();
		
		// support for whatsapp,facebook,instagram etc
		public abstract void shareVideos();
		
		
	

		
}
