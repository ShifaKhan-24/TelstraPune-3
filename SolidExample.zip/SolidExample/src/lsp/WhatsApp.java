package lsp;

public class WhatsApp extends SocialMedia {

	@Override
	public void chatWithFriend() {
		// TODO Auto-generated method stub

	}

	@Override
	public void publishPost() {
		// TODO Auto-generated method stub
// here this feature is not supported in whats app ,so here we cant have substitute
		// here ,so here Liskov principle is not supported
	}

	@Override
	public void sharePhotos() {
		// TODO Auto-generated method stub

	}

	@Override
	public void shareVideos() {
		// TODO Auto-generated method stub

	}

	@Override
	public void makeGroupVideos() {
		// TODO Auto-generated method stub

	}

}
