package lspsolution;

// Here now Instagram what it support  that interface it can implement
// SImilary go ahead create other implementaion classes


public class InstagramSocialMedia implements SocialMedia //,VideoCallManager{

	@Override
	public void chatWithFriend() {
		// TODO Auto-generated method stub

	}

	@Override
	public void sharePhotos() {
		// TODO Auto-generated method stub

	}

	@Override
	public void shareVideos() {
		// TODO Auto-generated method stub

	}

	@Override
	public void makeGroupVideos() {
		// TODO Auto-generated method stub
		
	}

}
