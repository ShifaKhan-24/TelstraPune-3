package lspsolution;

public interface PostMediaManager 
{
	
			public abstract void publishPost();
}
