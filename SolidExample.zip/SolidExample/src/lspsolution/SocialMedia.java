package lspsolution;

public interface SocialMedia {

// here we have identified some common features supported by all clients
	
public abstract void chatWithFriend();

	
	
		
		// support for whatsapp,facebook,instagram etc
		public abstract void sharePhotos();
		
		// support for whatsapp,facebook,instagram etc
		public abstract void shareVideos();
		
		
}
