package lspsolution;

public interface VideoCallManager {
	// support for whatsapp,facebook,instagram etc
	public abstract void makeGroupVideos();

}
