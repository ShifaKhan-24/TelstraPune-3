package ocp;

public class PhoneNotifcationService implements NotificationService {

	@Override
	public void sendOtp(String medium) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sendTransactionRepoort(String medium) {
		// TODO Auto-generated method stub

	}


}
