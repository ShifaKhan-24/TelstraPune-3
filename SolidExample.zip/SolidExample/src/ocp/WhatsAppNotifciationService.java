package ocp;

public class WhatsAppNotifciationService implements NotificationService {

	@Override
	public void sendOtp(String medium) {
		// logic for inteagrtion with whatsapp api
		

	}

	@Override
	public void sendTransactionRepoort(String medium) {
		// TODO Auto-generated method stub

	}

}
