class ListCollectionDemo
{


    printListCollection()
    {
        let course = [
            { course: 'Alice', age: 25 },
            { name: 'Bob', age: 30 },
            { name: 'Charlie', age: 35 }
        ];
    }

}
