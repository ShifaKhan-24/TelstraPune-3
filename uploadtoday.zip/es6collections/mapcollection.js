class MapCollectionDemo
{


    printMapCollection()
    {
      var mapdata = new Map([["J",'Java'],["P",'Python'],['S','Spring']]);  

      console.log(mapdata)
      var iterator = mapdata.entries(); 
       console.log(iterator.next());



var  mapkeys = mapdata.keys(); 
console.log("Keys:"+ mapkeys.next().value); 

var  mapValues = mapdata.values(); 
console.log("Keys:"+ mapValues.next().value); 

var iterator1 = mapdata.entries(); 
var iteratorValues = iterator1.next() 

while(!iteratorValues.done){
    let [key, value] = iteratorValues.value; 
    console.log(key,":"+value)
  iteratorValues=  iterator1.next();

}


}

    }



var mapobj=new MapCollectionDemo()
mapobj.printMapCollection()
