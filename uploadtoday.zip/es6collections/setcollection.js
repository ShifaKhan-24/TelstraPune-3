class SetCollectionDemo
{


    printSetCollection()
    {
      var setdata = new Set(['a','b','c','d','a']);  
      console.log(setdata)
      var iterator = setdata.values(); 
console.log(iterator.next());


// next
for(var setvalue of setdata.values())
{
console.log(setvalue)
}
    }
}
var setobj=new SetCollectionDemo()
setobj.printSetCollection()
