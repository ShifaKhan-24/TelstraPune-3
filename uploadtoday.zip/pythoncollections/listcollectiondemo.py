# List is a mutable collection

listcontainer = [10, 20, 30]

print(listcontainer)
listcontainer.append(9)
print(listcontainer)
anotherlist = ["Java", "python", "C++"]
listcontainer.append(anotherlist)
print(listcontainer)
listcontainer.insert(2, 9)
print(listcontainer)

anotherlist.sort()  # ascending order by default False
anotherlist.sort(reverse=True)  # descending order  True
print(anotherlist)

# iterate over the list
for i in listcontainer: 
    print(i)
   
    
items = 0
 
while items < len(listcontainer):
    print(listcontainer[items])
    items += 1
    

