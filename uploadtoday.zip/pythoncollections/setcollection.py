setempid = {2, 5, 2, 7, 1}
print(setempid)

setempidname = {'Kumar', 10, 3, 'Raju', 3}
print('Set of mixed data types:', setempidname)


# empty set
emptyset = {}
print(type(emptyset))  # intenally it will create as dictoinary 
emptyset = set()
print(type(emptyset))  # now it will create as set 


# add to set
setempid.add(0)
print(setempid)

# update set ie it can update with other collection
listdata = [10, 20, 60]
tupledata = ('a', 'p', 'e')
setempid.update(listdata)
setempid.update(tupledata)

print(setempid)


# remove

removedvalue = setempid.discard('e')
print(setempid)

# iterate

for items in setempid:
    print(items)
    
    # size of set
    
print("Size is:", len(setempid))
    
