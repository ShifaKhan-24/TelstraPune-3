# tuple is a immutable collection

tuplecontainer = (10, 20, 30)
listcontainer = [10, 20, 30]
# print(dir(tuplecontainer))
# tuplecontainer[0] = 70

# print(dir(listcontainer))
# tuplecontainer.append(90)
print(tuplecontainer)

# negative indexing
print(tuplecontainer[-2])

# slicing
tupleLanguages = ("Java", "C++", "Python", "c#")
print(tupleLanguages[2:])
print(tupleLanguages[::-1])
print(tupleLanguages[1:3])


# anotherlist = ["Java", "python", "C++"]
# listcontainer.append(anotherlist)
# print(listcontainer)
# listcontainer.insert(2, 9)
# print(listcontainer)

# anotherlist.sort()  # ascending order by default False
# anotherlist.sort(reverse=True)  # descending order  True
# print(anotherlist)

# # iterate over the list
# for i in listcontainer: 
#     print(i)
   
    
# items = 0
 
# while items < len(listcontainer):
#     print(listcontainer[items])
#     items += 1
    

